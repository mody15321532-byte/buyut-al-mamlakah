package com.example.eagles_eye_security

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
